#!/bin/bash
echo "Введите ваше имя:"
read username
echo "Привет, $username!"

